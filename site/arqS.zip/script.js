// =========================================================
// script.js — lógica interativa do site de aniversário/pedido
// =========================================================

document.addEventListener('DOMContentLoaded', () => {
  const btnSim = document.getElementById('btn-sim');
  const btnNao = document.getElementById('btn-nao');
  const grupoBotoes = document.getElementById('grupo-botoes');
  const cardComemoracao = document.getElementById('card-comemoracao');

  // Só executa a lógica abaixo se estivermos na página do pedido
  if (!btnSim || !btnNao || !grupoBotoes) return;

  const MARGEM = 12; // margem de segurança das bordas da tela, em px

  /**
   * Move o botão "Não" para uma posição aleatória dentro dos limites
   * visíveis da viewport, evitando que ele saia da tela.
   */
  function fugirBotaoNao() {
    const larguraBotao = btnNao.offsetWidth;
    const alturaBotao = btnNao.offsetHeight;

    const larguraDisponivel = window.innerWidth - larguraBotao - MARGEM * 2;
    const alturaDisponivel = window.innerHeight - alturaBotao - MARGEM * 2;

    const novoX = MARGEM + Math.random() * Math.max(larguraDisponivel, 0);
    const novoY = MARGEM + Math.random() * Math.max(alturaDisponivel, 0);

    btnNao.style.position = 'fixed';
    btnNao.style.left = `${novoX}px`;
    btnNao.style.top = `${novoY}px`;
  }

  // Computador: foge ao passar o mouse por cima
  btnNao.addEventListener('mouseover', fugirBotaoNao);

  // Celular: foge ao tocar (touchstart) ou ao primeiro contato do ponteiro
  btnNao.addEventListener('touchstart', (evento) => {
    evento.preventDefault();
    fugirBotaoNao();
  }, { passive: false });

  btnNao.addEventListener('pointerdown', (evento) => {
    // Evita disparo duplo em dispositivos que também emitem touchstart
    if (evento.pointerType === 'touch') return;
    fugirBotaoNao();
  });

  // Reposiciona o botão "Não" se a tela for redimensionada/rotacionada,
  // garantindo que ele continue dentro dos limites visíveis.
  window.addEventListener('resize', () => {
    if (btnNao.style.position === 'fixed') {
      fugirBotaoNao();
    }
  });

  /**
   * Ação do botão "SIM": dispara confete e mostra o card de comemoração.
   */
  btnSim.addEventListener('click', () => {
    dispararConfete();
    grupoBotoes.style.display = 'none';
    cardComemoracao.classList.add('mostrar');
  });

  function dispararConfete() {
    if (typeof confetti !== 'function') return;

    const duracao = 3 * 1000;
    const fimEm = Date.now() + duracao;

    const cores = ['#A569BD', '#D4E6F1', '#E8DAEF', '#1B4F72'];

    (function disparo() {
      confetti({
        particleCount: 6,
        angle: 60,
        spread: 70,
        origin: { x: 0 },
        colors: cores
      });
      confetti({
        particleCount: 6,
        angle: 120,
        spread: 70,
        origin: { x: 1 },
        colors: cores
      });

      if (Date.now() < fimEm) {
        requestAnimationFrame(disparo);
      }
    })();

    // Uma explosão central logo de início, para um impacto imediato
    confetti({
      particleCount: 120,
      spread: 100,
      origin: { y: 0.6 },
      colors: cores
    });
  }
});
